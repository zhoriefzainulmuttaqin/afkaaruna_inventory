@extends('layout.navbar')
@section('container')
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab eligendi laboriosam hic, perferendis, architecto quos fugit
    soluta voluptatum mollitia, eveniet impedit unde iure sapiente ipsum aliquid veritatis ad. Rem, ab.
@endsection
